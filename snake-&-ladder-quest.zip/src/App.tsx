import React, { useState, useEffect, useCallback, useRef } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Dice5, RotateCcw, Trophy, ArrowUpRight, ArrowDownRight } from 'lucide-react';

// Game Configuration
const BOARD_SIZE = 10;
const TOTAL_CELLS = BOARD_SIZE * BOARD_SIZE;

const LADDERS: Record<number, number> = {
  2: 38,
  7: 14,
  8: 31,
  15: 26,
  21: 42,
  28: 84,
  36: 44,
  51: 67,
  71: 91,
  78: 98,
  87: 94,
};

const SNAKES: Record<number, number> = {
  16: 6,
  46: 25,
  49: 11,
  62: 19,
  64: 60,
  74: 53,
  89: 68,
  92: 88,
  95: 75,
  99: 80,
};

// Helper to get coordinates for a cell number
const getCoords = (n: number) => {
  const rowFromBottom = Math.floor((n - 1) / BOARD_SIZE);
  const isEvenRow = rowFromBottom % 2 === 0;
  const col = isEvenRow ? (n - 1) % BOARD_SIZE : (BOARD_SIZE - 1) - ((n - 1) % BOARD_SIZE);
  const x = col * 10; // Percentage based for responsiveness
  const y = (BOARD_SIZE - 1 - rowFromBottom) * 10;
  return { x, y };
};

export default function App() {
  const [playerPosition, setPlayerPosition] = useState(1);
  const [diceValue, setDiceValue] = useState<number | null>(null);
  const [isRolling, setIsRolling] = useState(false);
  const [gameStatus, setGameStatus] = useState<'playing' | 'won'>('playing');
  const [message, setMessage] = useState('Roll the dice to start!');
  const [history, setHistory] = useState<string[]>([]);

  const addHistory = (msg: string) => {
    setHistory(prev => [msg, ...prev].slice(0, 5));
  };

  const rollDice = useCallback(() => {
    if (isRolling || gameStatus === 'won') return;

    setIsRolling(true);
    setMessage('Rolling...');

    // Simulate dice roll animation delay
    setTimeout(() => {
      const roll = Math.floor(Math.random() * 6) + 1;
      setDiceValue(roll);
      setIsRolling(false);
      handleMove(roll);
    }, 600);
  }, [isRolling, gameStatus, playerPosition]);

  const handleMove = (roll: number) => {
    const nextPos = playerPosition + roll;

    if (nextPos > TOTAL_CELLS) {
      setMessage(`Rolled a ${roll}. Need exactly ${TOTAL_CELLS - playerPosition} to win!`);
      addHistory(`Rolled ${roll}, but too high.`);
      return;
    }

    setPlayerPosition(nextPos);
    setMessage(`Rolled a ${roll}! Moving to ${nextPos}.`);
    addHistory(`Rolled ${roll}, moved to ${nextPos}.`);

    if (nextPos === TOTAL_CELLS) {
      setGameStatus('won');
      setMessage('CONGRATULATIONS! YOU WON!');
      addHistory('Reached 100! Victory!');
    }
  };

  // Check for snakes or ladders after movement
  useEffect(() => {
    if (gameStatus === 'won') return;

    let timeout: NodeJS.Timeout;

    if (LADDERS[playerPosition]) {
      const target = LADDERS[playerPosition];
      timeout = setTimeout(() => {
        setPlayerPosition(target);
        setMessage(`Lucky! A ladder took you from ${playerPosition} to ${target}!`);
        addHistory(`Ladder: ${playerPosition} -> ${target}`);
      }, 500);
    } else if (SNAKES[playerPosition]) {
      const target = SNAKES[playerPosition];
      timeout = setTimeout(() => {
        setPlayerPosition(target);
        setMessage(`Oh no! A snake bit you! Down from ${playerPosition} to ${target}.`);
        addHistory(`Snake: ${playerPosition} -> ${target}`);
      }, 500);
    }

    return () => clearTimeout(timeout);
  }, [playerPosition, gameStatus]);

  const restartGame = () => {
    setPlayerPosition(1);
    setDiceValue(null);
    setGameStatus('playing');
    setMessage('Game restarted. Good luck!');
    setHistory([]);
  };

  return (
    <div className="min-h-screen bg-stone-100 flex flex-col items-center justify-center p-4 font-sans text-stone-900">
      <div className="max-w-4xl w-full grid grid-cols-1 lg:grid-cols-3 gap-8 items-start">
        
        {/* Left Panel: Stats & Controls */}
        <div className="lg:col-span-1 space-y-6 order-2 lg:order-1">
          <div className="bg-white p-6 rounded-2xl shadow-sm border border-stone-200">
            <h1 className="text-2xl font-bold tracking-tight mb-2">Snake & Ladder</h1>
            <p className="text-stone-500 text-sm mb-6 italic">Reach cell 100 to win the quest.</p>
            
            <div className="space-y-4">
              <div className="flex items-center justify-between p-3 bg-stone-50 rounded-xl border border-stone-100">
                <span className="text-sm font-medium text-stone-600 uppercase tracking-wider">Position</span>
                <span className="text-xl font-mono font-bold">{playerPosition}</span>
              </div>

              <div className="flex flex-col items-center justify-center p-8 bg-stone-50 rounded-xl border border-stone-100 relative overflow-hidden">
                <AnimatePresence mode="wait">
                  {diceValue ? (
                    <motion.div
                      key={diceValue}
                      initial={{ scale: 0.5, opacity: 0, rotate: -45 }}
                      animate={{ scale: 1, opacity: 1, rotate: 0 }}
                      className="text-5xl font-bold text-indigo-600"
                    >
                      {diceValue}
                    </motion.div>
                  ) : (
                    <Dice5 className="w-12 h-12 text-stone-300" />
                  )}
                </AnimatePresence>
                <span className="mt-2 text-xs text-stone-400 uppercase font-semibold">Last Roll</span>
              </div>

              <button
                onClick={rollDice}
                disabled={isRolling || gameStatus === 'won'}
                className={`w-full py-4 rounded-xl font-bold text-white transition-all shadow-md active:scale-95 flex items-center justify-center gap-2 ${
                  gameStatus === 'won' 
                    ? 'bg-stone-400 cursor-not-allowed' 
                    : 'bg-indigo-600 hover:bg-indigo-700'
                }`}
              >
                {isRolling ? (
                  <motion.div
                    animate={{ rotate: 360 }}
                    transition={{ repeat: Infinity, duration: 0.5, ease: "linear" }}
                  >
                    <Dice5 className="w-6 h-6" />
                  </motion.div>
                ) : (
                  <>
                    <Dice5 className="w-6 h-6" />
                    Roll Dice
                  </>
                )}
              </button>

              <button
                onClick={restartGame}
                className="w-full py-3 rounded-xl font-semibold text-stone-600 bg-white border border-stone-200 hover:bg-stone-50 transition-colors flex items-center justify-center gap-2"
              >
                <RotateCcw className="w-4 h-4" />
                Restart Game
              </button>
            </div>
          </div>

          <div className="bg-white p-6 rounded-2xl shadow-sm border border-stone-200">
            <h2 className="text-sm font-bold uppercase tracking-widest text-stone-400 mb-4">Activity Log</h2>
            <div className="space-y-2">
              {history.length === 0 && <p className="text-stone-300 text-sm italic">No moves yet...</p>}
              {history.map((h, i) => (
                <motion.div 
                  initial={{ opacity: 0, x: -10 }}
                  animate={{ opacity: 1, x: 0 }}
                  key={i} 
                  className="text-sm text-stone-600 border-l-2 border-indigo-100 pl-3 py-1"
                >
                  {h}
                </motion.div>
              ))}
            </div>
          </div>
        </div>

        {/* Right Panel: The Board */}
        <div className="lg:col-span-2 order-1 lg:order-2">
          <div className="relative aspect-square bg-white rounded-2xl shadow-xl border-4 border-white overflow-hidden">
            {/* Grid Cells */}
            <div className="grid grid-cols-10 grid-rows-10 h-full w-full">
              {Array.from({ length: TOTAL_CELLS }).map((_, i) => {
                const cellNum = TOTAL_CELLS - i;
                // We need to handle the boustrophedon numbering for display
                // The grid is 10x10, top-left is cell 100, bottom-left is cell 1
                const row = Math.floor(i / 10);
                const isEvenRow = row % 2 === 0;
                const displayNum = isEvenRow 
                  ? (10 - row) * 10 - (i % 10)
                  : (9 - row) * 10 + (i % 10) + 1;

                const isLadderStart = LADDERS[displayNum];
                const isSnakeHead = SNAKES[displayNum];

                return (
                  <div 
                    key={displayNum}
                    className={`relative border-[0.5px] border-stone-100 flex items-center justify-center text-[10px] font-mono font-medium ${
                      (Math.floor((displayNum-1)/10) + (displayNum-1)%10) % 2 === 0 
                        ? 'bg-stone-50/50' 
                        : 'bg-white'
                    }`}
                  >
                    <span className="absolute top-1 left-1 opacity-20">{displayNum}</span>
                    
                    {isLadderStart && (
                      <div className="flex flex-col items-center text-emerald-500 opacity-60">
                        <ArrowUpRight className="w-4 h-4" />
                        <span className="text-[8px] font-bold">UP</span>
                      </div>
                    )}
                    {isSnakeHead && (
                      <div className="flex flex-col items-center text-rose-500 opacity-60">
                        <ArrowDownRight className="w-4 h-4" />
                        <span className="text-[8px] font-bold">DOWN</span>
                      </div>
                    )}
                  </div>
                );
              })}
            </div>

            {/* SVG Overlay for Snakes and Ladders */}
            <svg className="absolute inset-0 w-full h-full pointer-events-none overflow-visible">
              <defs>
                <marker id="arrowhead" markerWidth="10" markerHeight="7" refX="0" refY="3.5" orient="auto">
                  <polygon points="0 0, 10 3.5, 0 7" fill="currentColor" />
                </marker>
              </defs>
              
              {/* Draw Ladders */}
              {Object.entries(LADDERS).map(([start, end]) => {
                const s = getCoords(parseInt(start));
                const e = getCoords(end);
                return (
                  <line
                    key={`l-${start}`}
                    x1={`${s.x + 5}%`} y1={`${s.y + 5}%`}
                    x2={`${e.x + 5}%`} y2={`${e.y + 5}%`}
                    stroke="#10b981"
                    strokeWidth="3"
                    strokeDasharray="5,5"
                    className="opacity-30"
                  />
                );
              })}

              {/* Draw Snakes */}
              {Object.entries(SNAKES).map(([start, end]) => {
                const s = getCoords(parseInt(start));
                const e = getCoords(end);
                const midX = (s.x + e.x) / 2 + (s.x < e.x ? 5 : -5);
                const midY = (s.y + e.y) / 2;
                return (
                  <path
                    key={`s-path-${start}`}
                    d={`M ${s.x + 5}% ${s.y + 5}% Q ${midX + 5}% ${midY}% ${e.x + 5}% ${e.y + 5}%`}
                    stroke="#f43f5e"
                    strokeWidth="3"
                    fill="none"
                    className="opacity-30"
                  />
                );
              })}
            </svg>

            {/* Player Token */}
            <motion.div
              animate={{ 
                left: `${getCoords(playerPosition).x + 5}%`, 
                top: `${getCoords(playerPosition).y + 5}%` 
              }}
              transition={{ type: "spring", stiffness: 300, damping: 30 }}
              className="absolute w-[6%] h-[6%] -ml-[3%] -mt-[3%] z-20"
            >
              <div className="w-full h-full bg-indigo-600 rounded-full shadow-lg border-2 border-white flex items-center justify-center">
                <div className="w-2 h-2 bg-white rounded-full animate-pulse" />
              </div>
            </motion.div>

            {/* Win Overlay */}
            <AnimatePresence>
              {gameStatus === 'won' && (
                <motion.div
                  initial={{ opacity: 0 }}
                  animate={{ opacity: 1 }}
                  className="absolute inset-0 z-50 bg-indigo-600/90 flex flex-col items-center justify-center text-white p-8 text-center"
                >
                  <motion.div
                    initial={{ scale: 0 }}
                    animate={{ scale: 1 }}
                    transition={{ type: "spring", delay: 0.2 }}
                  >
                    <Trophy className="w-24 h-24 mb-6 text-yellow-400" />
                  </motion.div>
                  <h2 className="text-4xl font-black mb-2">VICTORY!</h2>
                  <p className="text-indigo-100 mb-8 max-w-xs">You've conquered the board and reached cell 100!</p>
                  <button
                    onClick={restartGame}
                    className="px-8 py-4 bg-white text-indigo-600 rounded-xl font-bold hover:bg-indigo-50 transition-colors shadow-xl"
                  >
                    Play Again
                  </button>
                </motion.div>
              )}
            </AnimatePresence>
          </div>

          {/* Status Message */}
          <div className="mt-6 text-center">
            <motion.p 
              key={message}
              initial={{ opacity: 0, y: 5 }}
              animate={{ opacity: 1, y: 0 }}
              className={`text-lg font-medium ${gameStatus === 'won' ? 'text-indigo-600 font-bold' : 'text-stone-600'}`}
            >
              {message}
            </motion.p>
          </div>
        </div>
      </div>
    </div>
  );
}
